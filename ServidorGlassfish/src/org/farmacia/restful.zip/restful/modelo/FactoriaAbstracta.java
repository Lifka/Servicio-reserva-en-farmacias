package org.farmacia.restful.modelo;


public abstract class FactoriaAbstracta {
	public abstract void createObjects();
}
