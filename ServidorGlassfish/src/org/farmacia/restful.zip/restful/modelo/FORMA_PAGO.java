package org.farmacia.restful.modelo;

public enum FORMA_PAGO {
	TARJETA, CONTRARREMBOLSO, PAYPAL, SIN_ESTABLECER
}
