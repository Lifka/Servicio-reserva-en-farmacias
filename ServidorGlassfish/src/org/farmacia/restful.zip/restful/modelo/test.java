package org.farmacia.restful.modelo;


public class test {

	public static void main(String[] args) {
		System.out.println("Hola mundo");
		    
	}

}
