package org.farmacia.restful.modelo;

public enum Departamento {
	MEDICAMENTOS,HOMEOPATIA,PERFUMERIA, SIN_CLASIFICAR
}
